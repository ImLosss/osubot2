import { Client, ColorResolvable, MessageEmbed, MessageOptions, TextBasedChannel } from 'discord.js';
import log4js from 'log4js';
import { getLogger } from '../Loggers';
import { OahrDiscord } from './OahrDiscord';

let discordClient: Client | undefined;
let ahrs: { [index: string]: OahrDiscord };

export function setContext(client: Client, ahrs_: { [index: string]: OahrDiscord }) {
  discordClient = client;
  ahrs = ahrs_;
}

const COLOR_MAP: { [key: string]: ColorResolvable } = {
  'white': 'WHITE', 'grey': 'GREY', 'black': 'DARK_BUT_NOT_BLACK',
  'blue': 'BLUE', 'cyan': 'AQUA', 'green': 'GREEN',
  'magenta': 'LUMINOUS_VIVID_PINK', 'red': 'RED', 'yellow': 'YELLOW'
};

export function configure(config: any, layouts: any) {
  let layout = layouts.colouredLayout;
  if (config.layout) {
    layout = layouts.layout(config.layout.type, config.layout);
  }

  //create a new appender instance
  /* loggingEvent sample
        categoryName:'default'
        context:{channel: 'mp_123'}
        data:(1) ['aaa']
        level:Level {level: 20000, levelStr: 'INFO', colour: 'green'}
        pid:18048
        startTime:Sat Aug 28 2021 22:30:41 GMT+0900  */
  return async (loggingEvent: log4js.LoggingEvent) => {
    if (discordClient) {
      try {
        const ch = getDiscordChannel(loggingEvent.context);
        if (ch) {
          const msg = layout(loggingEvent, config.timezoneOffset);
          const content = createContent(loggingEvent, msg);
          await ch.send(content);
        }
      } catch (e: any) {
        const logger = getLogger('discord_apd');
        logger.error(`@DiscordAppender#configure\n${e.message}\n${e.stack}`);
        const ahr = ahrs[loggingEvent.context.channelId];
        if (ahr) {
          ahr.stopTransferLog();
        }
      }
    }
  };
}

function getDiscordChannel(context: any): TextBasedChannel | undefined {
  if (discordClient && context && context.transfer && context.guildId && context.channelId) {
    const guild = discordClient.guilds.cache.get(context.guildId);
    const ch = guild?.channels.cache.get(context.channelId);
    if (ch && ch.isText()) {
      return ch;
    }
  }
  return undefined;
}

function createContent(ev: log4js.LoggingEvent, msg: string): string | MessageOptions {
  const color = COLOR_MAP[ev.level.colour] ?? 'DEFAULT';
  switch (ev.categoryName) {
    case 'chat':
      if (ev.data.length === 3) {
        return `> **${ev.data[1]}**: ${ev.data[2]}`;
      } else {
        return `> ${msg}`;
      }
    case 'inout':
      const min = msg.match(/\+\x1b\[32m (.+?) \x1B\[0m/);
      const mout = msg.match(/-\x1b\[31m (.+?) \x1B\[0m/);
      if (min || mout) {
        let msg = '';
        if (min) {
          msg += `**In** ${min[1]} `;
        }
        if (mout) {
          msg += `**Out** ${mout[1]}`;
        }
        return { embeds: [new MessageEmbed().setColor(color).setDescription(msg)] };
      }
      break;
  }
  if (log4js.levels.WARN.level <= ev.level.level) {
    return { embeds: [new MessageEmbed().setColor(color).setDescription(msg)] };
  }
  return `\`${ev.categoryName}\` ${msg}`;
}
