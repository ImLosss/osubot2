import { startLogServer } from './LogServer';

startLogServer(3112);
