//import * as trial from './WebServerTrial.js';
//trial.webServerTrial();

import { trial } from './DiscordTrial';
trial();
